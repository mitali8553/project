from django.contrib import admin
from Shoppingapp.models import Contact,Product
# Register your models here.

admin.site.register(Contact)
admin.site.register(Product)